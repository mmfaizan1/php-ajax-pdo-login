<?php
include('includes/session-set.php');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login Example PHP</title>
	<link rel="stylesheet" type="text/css" href="public/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="public/css/style.css">
	<link rel="stylesheet" type="text/css" href="public/css/jquery-confirm.min.css">
</head>
<body>
	<div class="container">
		<div class="jumbotron form-div">
			<div class="row">
				<div class="col-md-6 col-sm-12">
					<div class="error-div"></div>
				</div>
			</div>
			<div class="row">
			  	<div class="col-md-6 col-sm-12">
			  		<?php
			  		if (isset($_GET['msg'])) {
			  			if ($_GET['msg'] == 'logged_out') {
			  				?><div class="alert alert-success"><p class="text-center">You are Logged Out Successfully</p></div><?php
			  			}else if ($_GET['msg'] == 'login_to_continue') {
			  				?><div class="alert alert-danger"><p class="text-center">Please Log In to Continue</p></div><?php
			  			}
			  		}
			  		?>
			  		<h1>Hello, Visitor!</h1>
		  			<p>Login to Your Account</p>
				  	<form class="form" method="post" id="login-form">
						<div class="form-group">
						    <label>Email address</label>
						    <input type="email" class="form-control" id="email" name="email" placeholder="Email">
						</div>
						<div class="form-group pass_show">
						    <label>Password</label>
						    <input type="password" class="form-control" id="password" name="password" placeholder="Password">
						</div>
				        <div class="form-group">	
				        	<button type="button" name="login" id="login" class="btn btn-primary" value="login">Log In</button>
				        </div>
					</form>
				</div>
				<div class="col-sm-12 col-md-6">
					<img src="public/img/lock.png" class="img-responsive">
				</div>
		</div>
	</div>
	<script type="text/javascript" src="public/js/jquery.min.js"></script>
	<script type="text/javascript" src="public/js/jquery-confirm.min.js"></script>
	<script type="text/javascript" src="public/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="public/js/scripts.js"></script>
</body>
</html>