<?php session_start();
if (isset($_POST['submit'])) {
	include("../includes/functions.php");
	$email = $_POST['email'];
	$password = $_POST['password'];
	$status = input_received($_POST);
	if ($status === TRUE) {
		$status = validate_sanitize($email);
		if ($status === 'invalid_email_format') {
			echo "invalid_email";
		}else{
			//Login Code
			include("../includes/db.php");
			$connection = connect_db();
			$email = $email;
			$password = $password;
			$sql = "SELECT * FROM `users` WHERE `email`=? AND `password`=?";
			$stmt = mysqli_prepare($connection, $sql);
			if ($stmt) {
				mysqli_stmt_bind_param($stmt, 'ss', $email, $password);
				mysqli_stmt_bind_result($stmt, $db_id, $db_fullname, $db_email, $db_password);
				mysqli_stmt_execute($stmt);
				mysqli_stmt_store_result($stmt);
				mysqli_stmt_fetch($stmt);
				$rows = mysqli_stmt_num_rows($stmt);
				if ($rows > 0) {
					$_SESSION["user_id"] = $db_id;
					$_SESSION["name"] = $db_fullname;
					$_SESSION["email"] = $db_email;
					echo "valid";
				}else{
					echo "invalid_credentials";
					die();
				}
			}else{
				echo "invalid_credentials";	
				die();
			}
		}
	}else{
		echo "empty";
		die();
	}
}
?>