<?php
function input_received($arg){
	if (is_array($arg)) {
		foreach ($arg as $input) {
			if ($input == "" OR $input == NULL) {
				return "missing_input";
			}
		}
	}
	return TRUE;
}
$error;
function validate_sanitize($email){
	$email = filter_var($email, FILTER_SANITIZE_EMAIL);
	$email = filter_var($email, FILTER_VALIDATE_EMAIL);
	if (!$email) {
    	return "invalid_email_format";
	}
	return $email;
}
?>