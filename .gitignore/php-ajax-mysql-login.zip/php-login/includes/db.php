<?php
include('config.php');
function connect_db(){
	$db = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
	if (!$db) {
		die("Failed To Connect to DB");
	}
	return $db;
}
?>