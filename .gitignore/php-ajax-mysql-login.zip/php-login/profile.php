<?php 
include('includes/session-not-set.php');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login Example PHP</title>
	<link rel="stylesheet" type="text/css" href="public/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="public/css/style.css">
</head>
<body>
	<div class="container">
		<div class="jumbotron">
			<?php
	  		if (isset($_GET['msg'])) {
	  			if ($_GET['msg'] == 'already_logged_in') {
	  				?><div class="alert alert-danger"><p class="text-center">You are already Logged In.</p></div><?php
	  			}
	  		}
	  		?>
		    <h1>Profile</h1>
		    <p>Welcome: <?php echo $_SESSION['name']; ?>! <a href="includes/logout.php">Logout</a></p>
		</div>
	</div>
	<script type="text/javascript" src="public/js/jquery.min.js"></script>
	<script type="text/javascript" src="public/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="public/js/scripts.js"></script>
</body>
</html>